#!/usr/bin/env perl 
# A test script that allows a Logo-like program to be editted and run 
# uses GUIDeFATE (which in turn depends on Wx , GTK, QT, or Tk)
# This file designed to be called by Executioner for backend testing
# It uses Language::SIMPLE extended to interpret a script that can then be used
# to generate an SVG file, which is displayed in a graphical panel

use strict;
use warnings;
use lib '../lib/';

use GUIDeFATE;
use Language::SIMPLE;

my $window=<<END;
+------------------------------------------------------------------------------+
|T  LOGO to SVG convertor                                                      |
+M-----------------------------------------------------------------------------+
|+T---------------------++I---------------------------------------------------+|
||# Simple Logo         ||simplelogo.svg                                      ||
||                      ||                                                    ||
||                      ||                                                    ||
||                      ||                                                    ||
||                      ||                                                    ||
||                      ||                                                    ||
||                      ||                                                    ||
||                      ||                                                    ||
||                      ||                                                    ||
||                      ||                                                    ||
||                      ||                                                    ||
||                      ||                                                    ||
||                      ||                                                    ||
||                      ||                                                    ||
||                      ||                                                    ||
||                      ||                                                    ||
||                      ||                                                    ||
|+----------------------+|                                                    ||
|[                      ]+----------------------------------------------------+|
|{Start}{Draw}{Draw}{Draw}{Draw}{Draw}{Draw}{Draw}{Draw}{Draw}{Draw}{Draw}{Dra}|
+------------------------------------------------------------------------------+

Logs=Logs,SVG,Listing

Menu
-File
--New
--Open
--Save Script
--Quit
-Image
--Draw
--Save SVG
--Save PNG
-Examples
--Star
--Spiral
--Flower
--About

timer 500 doStuff 1

END


my @files = </home/saif/Pictures/*.jpg>;
my $number=0;
my $timer;

my $result=0;
my $backend=$ARGV[0]?$ARGV[0]:"qt";
my $assist=$ARGV[1]?$ARGV[1]:"v";
my $gui=GUIDeFATE->new($window,$backend,$assist);
my $frame=$gui->getFrame()||$gui;



if ($backend =~/wx/){
	#use Wx;
	#use base 'Wx::Frame';
	#use Wx::Event qw(EVT_BUTTON EVT_TIMER);
	#$timer  = Wx::Timer->new(
	#				$frame,      # Parent Frame
	#				-1,         # Timer ID
	#);
	#EVT_TIMER $frame, $timer, \&doStuff;    
	#$timer->Start(500);  #
}
#elsif ($backend =~/gtk/){
	#use AE;
    #use Time::HiRes qw(time);
	#$timer = AE::timer 1, 0.5, \&doStuff;
#}
#elsif ($backend =~/tk/){
	#use AE;
    #use Time::HiRes qw(time);
	#$timer = AE::timer 1, 0.5, \&doStuff;
#}

elsif ($backend =~/qt/){
	#$frame->setTimer({function=>\&doStuff});
	
}


sub doStuff{
	if ($files[$number] && (-f "$files[$number]")){
		$frame->appendValue("TextCtrl1",$files[$number]."\n");
		$frame->setImage("Image2",$files[$number++]);
	}
	elsif($number>=@files){
		$number=0;
	}
	else {$number++}
	
	
}

my $test= SIMPLE->new();
$test->extend("logo");
$gui->MainLoop;



sub btn5{
  }
  
  
END {
   $timer=undef;
}


  
  

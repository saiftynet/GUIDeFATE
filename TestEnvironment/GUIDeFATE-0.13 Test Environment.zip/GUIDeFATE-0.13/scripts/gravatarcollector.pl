#!/usr/bin/env perl 
# A test script that identifies Gravatars and collects them in a folder
# GUIDeFATE (which in turn depends on other graphical toolkits)
# This file designed to be called by Executioner for backend testing
# The main purpose is to test the various backends specially Websockets

use strict;
use warnings;
use GUIDeFATE;
use LWP::Simple;

my $window=<<END;
+------------------------------------------------+
|T The Gravatar Collector                        |
+M-----------------------------------------------+
|  The Gravatar Collector                        |
|  [                         ] {Enter URL/email} |
|  {A}{B}{C}{D}{E}{F}{G}{H}{I}{J}{K}{L}{M}       |
|  {N}{O}{P}{Q}{R}{S}{T}{U}{V}{W}{X}{Y}{Z}       |
|  Gravatar Not Found                            |
|  +T----------------------+  +I--------------+  |    
|  |                       |  |               |  |
|  |                       |  |               |  |
|  |                       |  |               |  |
|  |                       |  |               |  |
|  |                       |  |               |  |
|  +-----------------------+  +---------------+  |
|  {<}              {>}       { QR Code/Photo }  |
|      0000 of 0000                              |
|       http://www.gravatar.com                  |
+------------------------------------------------+
END

my $backend=$ARGV[0]?$ARGV[0]:"qt";
my $assist=$ARGV[1]?$ARGV[1]:"q";
my $gui=GUIDeFATE->new($window,$backend,$assist);
my $frame=$gui->getFrame()||$gui;

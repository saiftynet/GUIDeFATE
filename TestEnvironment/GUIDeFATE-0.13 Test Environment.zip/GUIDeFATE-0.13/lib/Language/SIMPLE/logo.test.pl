  Vars=>{
	  version    =>  0.03,     # version
      dir        =>  180,      # initial direction
      fmTLX      =>  0,        # frame top left x coordinate
      fmTLY      =>  0,        # frame top left x coordinate
      fmWidth    =>  1000,
      fmHeight   =>  1000,
      font       =>  "italic 40px sans-serif",
      xPos       => 500,
      yPos       => 500,
      font       => {  family => "sans-serif",
		               size   => "80px",
		               style  => "italic",
		               fill   => "black",
		               rotate => 0,
		               anchor => 'start',
				   },
      colour     => 'black',
      thickness  => 3,
      pen        => 1,
      fill       => "",
      mode       => "line",
      minX       => 100,
      minY       => 100,
      maxX       => 100,
      maxY       => 100, 
      logs       => "",
      svgLines   => [],
      targetName => 'svg',
      layers     => {},
      groups     => {},
      clippaths  => {},
      pointArray => [], 
      directions => {  north      =>  180,
		               east       =>   90,
		               south      =>    0,
		               west       =>  -90,
		               northeast  =>  135,
		               northwest   => -135,
		               southeast  =>   45,
		               southeast  =>  -45,
				    },  
   },
   
   initialise=>sub{
      push @customBlocks, "group";
   
   },

   commands=>{
      fd=>sub{
        my $distance=shift;
        $distance=evaluate($distance);
        my $oldX=$extensions{logo}{Vars}{xPos};
        my $oldY=$extensions{logo}{Vars}{yPos};
        my $colour=$extensions{logo}{Vars}{colour};
        my $thickness=$extensions{logo}{Vars}{thickness};
        my $newX= sin($functions{rad}->($extensions{logo}{Vars}{dir}))*$distance+$oldX ;
        my $newY= cos($functions{rad}->($extensions{logo}{Vars}{dir}))*$distance+$oldY;
        
        $extensions{logo}{commands}{minmax}->($newX,$newY);
 
        $extensions{logo}{Vars}{xPos}=$newX;
        $extensions{logo}{Vars}{yPos}=$newY;
        
        my $mode= $extensions{logo}{Vars}{mode};
        $oldX=int($oldX);$oldY=int($oldY);$newX=int($newX);$newY=int($newY);
	    if ($mode=~ /(poly(gon|line))/){
			$extensions{logo}{commands}{addpoints}->( " ".$newX.",".$newY." ");
		}
		elsif ($mode eq "path"){
			if($extensions{logo}{Vars}{pen}==1){
			  $extensions{logo}{commands}{addpoints}->("L ".$newX.",".$newY." ");
		    }			
		}
		else {
           if($extensions{logo}{Vars}{pen}==1){
			  my $line=qq(<line x1="$oldX" y1="$oldY" x2="$newX" y2="$newY" style="stroke:$colour;stroke-width:$thickness" />\n);
			  push $extensions{logo}{Vars}{svgLines}, $line;
		   }
	    }	
     },
     
     bk =>sub{
		 my $distance=shift;
		 $extensions{logo}{commands}{fd}("-1*".$distance)
	 },
     
     forward=> sub{
		 my $distance=shift;
		 $extensions{logo}{commands}{fd}($distance);
	 },
     
     backward=> sub{
		 my $distance=shift;
		 $extensions{logo}{commands}{fd}("-1*".$distance);
	 },	
	 
     lt=>sub{
        my $delta=shift;
        $delta=   ($delta eq '')? 90:evaluate($delta);
        $extensions{logo}{Vars}{dir}+=$delta;  
           
     },
     
     left=> sub{
		 my $delta=shift;
		 $extensions{logo}{commands}{lt}($delta);
	 },
     
     rt=>sub{
        my $delta=shift;
        $delta=   ($delta eq '')? 90:evaluate($delta);
        $extensions{logo}{Vars}{dir}-=$delta;     
     },
     
     right=> sub{
		 my $delta=shift;
		 $extensions{logo}{commands}{rt}($delta);
	 }, 
	 
	 addpoints=>sub{
		 my $additions=shift;
		 $extensions{logo}{Vars}{svgLines}[-1]=~s/\"\/>/$additions\"\/>/;
	 },
 
     center => sub {
		my $target=shift;
		if ($target=~/all/){
			$extensions{logo}{Vars}{fmTLX}=($extensions{logo}{Vars}{minX}+$extensions{logo}{Vars}{maxX} - $extensions{logo}{Vars}{fmWidth} )/2;
			$extensions{logo}{Vars}{fmTLY}=($extensions{logo}{Vars}{minY}+$extensions{logo}{Vars}{maxY} - $extensions{logo}{Vars}{fmHeight})/2;
			
		}
		else{
            $extensions{logo}{Vars}{xPos}=($extensions{logo}{Vars}{fmWidth}  + $extensions{logo}{Vars}{fmTLX})/2;
            $extensions{logo}{Vars}{yPos}=($extensions{logo}{Vars}{fmHeight} + $extensions{logo}{Vars}{fmTLY})/2;
		}
     },
     
     circle => sub {
		 my $radius=shift;
		 $radius=evaluate($radius);
		 my ($x,$y)= (int ($extensions{logo}{Vars}{xPos}), int($extensions{logo}{Vars}{yPos}) );
		 my $line="<circle cx=\"$x\" cy=\"$y\" r=\"$radius\"   ".
		                                   "stroke=\"$extensions{logo}{Vars}{colour}\" ".
		                                   "stroke-width=\"$extensions{logo}{Vars}{thickness}\" ".
		                                   "fill=\"$extensions{logo}{Vars}{fill}\" />";
		 push $extensions{logo}{Vars}{svgLines},$line;
	 },
	  
     clear=>sub{
		logs("clear");
        $extensions{logo}{Vars}{svgLines}= [];
        $extensions{logo}{Vars}{mode}    = "line ";
        $extensions{logo}{Vars}{fmTLX}   = 0;
        $extensions{logo}{Vars}{fmTLY}   = 0;
        $extensions{logo}{Vars}{fmWidth} = 1000;
        $extensions{logo}{Vars}{fmHeight}= 1000;
        $extensions{logo}{Vars}{minX}    = 500;
        $extensions{logo}{Vars}{minY}    = 500;
        $extensions{logo}{Vars}{maxX}    = 500;
        $extensions{logo}{Vars}{maxY}    = 500;
        $extensions{logo}{Vars}{xPos}    = 500;
        $extensions{logo}{Vars}{yPos}    = 500;
     },
     	 
	 closepath=>sub{
		 if ($extensions{logo}{Vars}{mode} eq "path"){
			if ( $extensions{logo}{Vars}{svgLines}[-1]!~/Z\s*\"\/>/gi){
			    $extensions{logo}{Vars}{svgLines}[-1]=~s/\"\/>/Z\"\/>/g ;
			    $extensions{logo}{Vars}{svgLines}[-1]=~s/\n//g ;
			}		
		 }
	 },
     
     colour =>sub{
		my $colour=shift;
		if ($colour =~m/random/){
			$colour="rgb(".int(rand(256)).",".int(rand(256)).",".int(rand(256)).")";
		}
		$extensions{logo}{Vars}{colour}=$colour;
     },
  
     dir=>sub{
        my $newDir=shift;
        if (defined $extensions{logo}{Vars}{directions}{$newDir}){
			$extensions{logo}{Vars}{dir}=$extensions{logo}{Vars}{directions}{$newDir}
		}
        else {
			$extensions{logo}{Vars}{dir}=evaluate($newDir);
		}
     },
     
     drawTo=>sub{
		 
		 
	 },
     
     font => sub{
		 my  $params=shift;
		 foreach (split(",",$params) ){
		   $_=~/\s*([a-z]+)\s*=\s*(\S*)\s*$/;
		   $extensions{logo}{Vars}{font}{$1}=$2;
	     }
	 },
     
     
     image => sub{
		 qr{<image xlink:href="firefox.jpg" x="0" y="0" height="50px" width="50px"/>}
	 },
	 
         
     minmax=>sub{
	   my ($newX,$newY)=@_;
	   if ($newX>$extensions{logo}{Vars}{maxX}) {
		   $extensions{logo}{Vars}{maxX}=int($newX);}
       elsif ($newX<$extensions{logo}{Vars}{minX}) {
		   $extensions{logo}{Vars}{minX}=int($newX);}; 
       if ($newY>$extensions{logo}{Vars}{maxY}) {
		   $extensions{logo}{Vars}{maxY}=int($newY);}
       elsif ($newY<$extensions{logo}{Vars}{minY}) {
		   $extensions{logo}{Vars}{minY}=int($newY);}
	 },
	      
     move=>sub{
	   my $newPos=shift;
	   my ($x,$y)=split (",",$newPos);
	   $x=evaluate($x); $y=evaluate($y);
	   if ($extensions{logo}{Vars}{mode}  eq "path "){
		   $extensions{logo}{commands}{closepath}
	   }
	   else {
		   $extensions{logo}{Vars}{xPos}=$x;
		   $extensions{logo}{Vars}{yPos}=$y;
	   }
     },

     text=>sub{
		 my $text=shift;
		 $text=evaluate($text);
		 my %font=%{$extensions{logo}{Vars}{font}};
		 my $style=qq{style="font-size:$font{size};font-family:$font{family}; font-style:$font{style}; fill:$font{fill}; " };
		 my ($x,$y)= (int ($extensions{logo}{Vars}{xPos}), int($extensions{logo}{Vars}{yPos}) );
		 my $anchor=qq(text-anchor="$font{anchor}");
		 my $transform=qq{transform="rotate($font{rotate},$x,$y)"};
		 my $line=qq{<text $style $transform $anchor x= "$x" y="$y">$text</text>};
		 push $extensions{logo}{Vars}{svgLines}, $line;
	 },

	 pan=>sub{
		 my ($dir,$distance)=@_;
		 if (!$distance) {$distance=10};
		 if      ($dir eq "up")   { $extensions{logo}{Vars}{fmTLY}+=$distance }
		 elsif   ($dir eq "down") { $extensions{logo}{Vars}{fmTLY}-=$distance }
		 elsif   ($dir eq "left") { $extensions{logo}{Vars}{fmTLX}-=$distance }
		 elsif   ($dir eq "right"){ $extensions{logo}{Vars}{fmTLX}+=$distance }
		 else    {logline("Pan Direction $dir not recognised\n")}
	 },
	 
     pen=>sub{
       my $ud=shift;
       $ud=($ud=~/up|1/)?0:1;
       $extensions{logo}{Vars}{pen}=$ud;
       if ($extensions{logo}{Vars}{mode} eq "path"){
		   if (!$ud) { $extensions{logo}{commands}{closepath}->() }  # close path if pen raised
		   else {
			   my ($x,$y)= (int ($extensions{logo}{Vars}{xPos}), int($extensions{logo}{Vars}{yPos}) );
			   $extensions{logo}{commands}{addpoints}->("M $x $y ");
		   };
	   }
     },
   
     fill=>sub{
		my $colour=shift;
		if ($colour =~m/random/){
			$colour="rgb(".int(rand(256)).",".int(rand(256)).",".int(rand(256)).")";
		}
		$extensions{logo}{Vars}{fill}=$colour;
	 },
     
     mode =>sub{
        my $mode=shift;
        my $colour=$extensions{logo}{Vars}{colour};
        my $thickness=$extensions{logo}{Vars}{thickness};
        my $fill=$extensions{logo}{Vars}{fill};
        my ($x,$y)= (int ($extensions{logo}{Vars}{xPos}), int($extensions{logo}{Vars}{yPos}) );
        my $line;
        if ($mode=~ /(path|polyline|polygon|line)/) {
		  $mode=$1;
          $extensions{logo}{Vars}{mode}=$mode;
          if ($mode=~ /(poly(gon|line))/){
			  $line=qq(\n<$1 style="stroke:$colour;stroke-width:$thickness;fill:$fill" points="$x,$y "/>\n);
		  }
		  elsif ($mode eq "path"){
			  $line=qq(<path style="stroke:$colour;stroke-width:$thickness;fill:$fill; fill-rule:evenodd" d="M $x,$y "/>);
		  }
		  push $extensions{logo}{Vars}{svgLines}, $line;
        }
     },
     
     nl =>sub{
		 my $spacing=shift;
		 $spacing=evaluate($spacing) // 1;
		 $extensions{logo}{Vars}{yPos}+=($extensions{logo}{Vars}{font}{size}*$spacing)
	 },
	 
	 nextline=>sub{
		 $extensions{logo}{commands}{nl}
	 },
          
     rectangle => sub{
		 my $wh=shift;
		 my ($x,$y)= (int ($extensions{logo}{Vars}{xPos}), int($extensions{logo}{Vars}{yPos}) );
		 my  ($width,$height,$rx,$ry)=split(",", $wh);
		 ($width,$height,$rx,$ry)=map {($_ ne undef) ? evaluate($_) : 0}($width,$height,$rx,$ry);
		 my $line="<rect x=\"$x\" y=\"$y\" width=\"$width\"  height=\"$height\"  rx=\"$rx\"  ry=\"$ry\" ".
		                                   "stroke=\"$extensions{logo}{Vars}{colour}\" ".
		                                   "stroke-width=\"$extensions{logo}{Vars}{thickness}\" ".
		                                   "fill=\"$extensions{logo}{Vars}{fill}\" />";
		 push $extensions{logo}{Vars}{svgLines}, $line;
		  
     },
     
     resetlogo => sub{
		  $extensions{logo}{commands}{clear}->();
		  $commands{reset}->();
	 },
     
     target  =>sub{   # set the destination of newly created elements
		 my ($tg,$line)=@_;
		 if    ($tg=~/svg/)                      {  push $extensions{logo}{Vars}{svgLines},$line        }
		 elsif ($tg =~ /group\s+(\w+)\s*\$/)     {  $extensions{logo}{Vars}{groups}{$1}.=$line }
		 elsif ($tg =~ /clip\s+(\w+)\s*\$/)      {  $extensions{logo}{Vars}{clippaths}{$1}.=$line }
		 
	 },
     
     thickness => sub {
		 my $thickness=shift;
		 $extensions{logo}{Vars}{thickness}=evaluate($thickness);
	 },
     
     transform => sub{
     
     },
     
     svg => sub{
        return "<svg  viewBox=\" ". $extensions{logo}{Vars}{fmTLX}." ".$extensions{logo}{Vars}{fmTLY}.  
		                              " ".$extensions{logo}{Vars}{fmWidth}." ".$extensions{logo}{Vars}{fmHeight}."\"".
		                              " xmlns='http://www.w3.org/2000/svg' >\n".
		                              join ("\n",@{$extensions{logo}{Vars}{svgLines}}).
		                              "  </svg>";
     },
     
     svgout=>sub{
         my $svgFile=shift;
         $svgFile=~s/^\s+|\s+$//g;
         if ($svgFile!~/\.svg$/){$svgFile.='.svg'};
         logLine( "saving file to $svgFile\n");
         open (my $svg,'>',$svgFile);          
		 print $svg join("\n",@{$extensions{logo}{Vars}{svgLines}});
		 close $svg;
		 
	 },
	 
	 pngout=>sub{
		 
		 
	 },
	  
	 zoom=>sub {
		my $zoom=shift;
		$zoom=~/\s*(all|in|out)\s*(-?\d*)\s*$/;
		my ($zoom,$zf)=($1,$2);
		if (!$zf) {$zf=10};
		if ($zoom eq "all"){
		 $extensions{logo}{Vars}{fmTLX}    = $extensions{logo}{Vars}{minX};
		 $extensions{logo}{Vars}{fmTLY}    = $extensions{logo}{Vars}{minY};
		 $extensions{logo}{Vars}{fmWidth}  = $extensions{logo}{Vars}{maxX} - $extensions{logo}{Vars}{minX};
		 $extensions{logo}{Vars}{fmHeight} = $extensions{logo}{Vars}{maxY} - $extensions{logo}{Vars}{minY};
		}
		elsif ($zoom eq "in"){
		 $extensions{logo}{Vars}{fmTLX}   = int($extensions{logo}{Vars}{fmTLX}+($extensions{logo}{Vars}{fmWidth}) *($zf/200) );  
		 $extensions{logo}{Vars}{fmTLY}   = int($extensions{logo}{Vars}{fmTLY}+($extensions{logo}{Vars}{fmHeight})*($zf/200) ); 
		 $extensions{logo}{Vars}{fmHeight}= int($extensions{logo}{Vars}{fmHeight}*(1-$zf/100));
		 $extensions{logo}{Vars}{fmWidth} = int($extensions{logo}{Vars}{fmWidth}*(1-$zf/100));
	   }
	   elsif ($zoom eq "out"){
		 $extensions{logo}{commands}{zoom}->("in -$zf");
	   }
	 },
   },
   
   blockHeads=>{
      group=>sub{
         my ($gpName,$block)  =  @_;
         logLine("\n...Parsing group $gpName");
		 $extensions{logo}{Vars}{groups}{$targetName} ="group $gpName";
		 $extensions{logo}{Vars}{groups}{$gpName}  =    "";
		 push $extensions{logo}{Vars}{svgLines}, "<g id=\"$gpName\">";
		 execBlock(undef,$block);
		 push $extensions{logo}{Vars}{svgLines}, "<\g">";
      },

   
   },
   
 

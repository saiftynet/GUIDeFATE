#!/usr/bin/env perl 
#A test script that  plays Rock Paper Scissors Lizard Spock
#use GUIDeFATE (which in turn depends on Wx and Wx::Perl::Imagick)

use strict;
use warnings;
use GUIDeFATE qw<$frame>;

my $window=<<END;
+------------------------------------------------+
|T Rock Paper Scissors Lizard Spock              |
+------------------------------------------------+
|                                                |
| Play Rock Paper   +I------+                    |
| Scissors Lizard   |rock.jp|                    |
| Spock.  Click     |g      |                    |
| any button to     +-------+                    |
| play              { Rock  }                    |
|                                                |
|   +I------+                       +I------+    |
|   |Spock.j|       +I------+       |paper.j|    |
|   |pg     |       |sister.|       |pg     |    |
|   +-------+       |jpg    |       +-------+    |
|   { Spock }       +-------+       { Paper }    |
|                  I am ready                    |
|                                                |
|          +I------+         +I------+           |
|          |Lizard.|         |scissor|           |
|          |jpg    |         |s.jpg  |           |
|          +-------+         +-------+           |
|          {Lizard }         {Scissrs}           |
|                                                |
+------------------------------------------------+


END


my %options=qw/Rock rock.jpg Paper paper.jpg Scissors scissors.jpg Lizard Lizard.jpg Spock Spock.jpg/;

GUIDeFATE::convert($window);
my $gui=GUIDeFATE->new();
$gui->MainLoop;

sub btn5{
	print "Rock selected \n";
	getResults("Rock");
}

sub btn10{
	print "Spock selected \n";
	getResults("Spock");
}

sub btn11{
	print "Paper selected \n";
	getResults("Paper");
}

sub btn15{
	print "Lizard selected \n";
	getResults("Lizard");
}

sub btn16{
	print "Scissors selected \n";
	getResults("Scissors");
}

sub getResults{
	my $player= shift;
	my $computer=(keys %options)[rand 5];
	
	# setImage takes the Filename, id number of subpanel, and a pixel size (as a list)
	$frame->setImage($options{$computer},9,[136,128]); 

	
	my $result="";
	if ($player eq "Rock"){
		if ($computer eq "Rock")       {$result="Draw"}
		elsif($computer eq "Paper")    {$result="I cover You"}
		elsif($computer eq "Scissors") {$result="You crush me"}
		elsif($computer eq "Lizard")   {$result="You crush me"}
		else                           {$result="I vaporise you"}
	}
	if ($player eq "Paper"){
		if ($computer eq "Rock")       {$result="You cover me"}
		elsif($computer eq "Paper")    {$result="Draw"}
		elsif($computer eq "Scissors") {$result="I cut you"}
		elsif($computer eq "Lizard")   {$result="I eat you"}
		else                           {$result="You disprove me"}
	}	
	if ($player eq "Scissors"){
		if ($computer eq "Rock")       {$result="I crush you"}
		elsif($computer eq "Paper")    {$result="You cut me"}
		elsif($computer eq "Scissors") {$result="Draw"}
		elsif($computer eq "Lizard")   {$result="You decapitate me"}
		else                           {$result="I smash you"}
	}	
	if ($player eq "Lizard"){
		if ($computer eq "Rock")       {$result="I crush you"}
		elsif($computer eq "Paper")    {$result="You eat me"}
		elsif($computer eq "Scissors") {$result="I decapitate you"}
		elsif($computer eq "Lizard")   {$result="Draw"}
		else                           {$result="You poison me"}
	}	
	if ($player eq "Spock"){
		if ($computer eq "Rock")       {$result="You vaporise me"}
		elsif($computer eq "Paper")    {$result="I disprove you"}
		elsif($computer eq "Scissors") {$result="You smash me"}
		elsif($computer eq "Lizard")   {$result="I poison you"}
		else                           {$result="Draw"}
	}	
	print $result."\n";
	
	# This is using a Wx function...needs to be abstracted out. 
	$frame->{stattext12}->SetLabel($result);
	
}




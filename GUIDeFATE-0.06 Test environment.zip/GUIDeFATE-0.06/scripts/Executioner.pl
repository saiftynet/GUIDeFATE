#!/usr/bin/env perl 
#A test script that calls the test files in scripts folder
#use GUIDeFATE (which in turn depends on Wx)

use lib '../lib/';
use strict;
use warnings;
use GUIDeFATE;

my $window=<<END;
+--------------------------------------+
|T Start other apps                    |
+M-------------------------------------+
|  {Use Wx    }    wx    {Use Tk    }  |
|  {Calculator                      }  |
|  {Rock Paper Scissors Lizard Spock}  |
|  {GUI Gnuplotter                  }  |
|  { Text editor                    }  |
+--------------------------------------+

END


my $backend="wx";
my $gui=GUIDeFATE->new($window,$backend);
my $frame=$gui->getFrame;
$gui->MainLoop;



sub btn0 #called using button with label Calculator                       
  {
	  $backend="wx";
	  $frame->setLabel("Wx",2);
  }
  
  sub btn1 #called using button with label Calculator                       
  {
	  $backend="tk";
	  $frame->setLabel("Tk",2);
  }

sub btn3 #called using button with label Calculator                       
  {
  system("(perl -I../lib/ calculator.pl $backend &)");
   };
sub btn4 #called using button with label Rock Paper Scissors Lizard Spock 
  {
  system("(perl -I../lib/ rpsls.pl $backend &)");
  };

sub btn5 #called using button with label GUI Gnuplotter                   
  {
  system("(perl -I../lib/ GUIgnuplot.pl $backend &)");
   };

sub btn6 #called using button with label  Text editor                     
  {
  system("(perl -I../lib/ texteditor.pl $backend &)");
   };

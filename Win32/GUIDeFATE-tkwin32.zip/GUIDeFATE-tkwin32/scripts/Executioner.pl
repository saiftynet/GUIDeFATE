#!/usr/bin/env perl 
#A test script that calls the test files in scripts folder
#use GUIDeFATE (which in turn depends on Wx)

use lib '..\\lib\\';
use strict;
use warnings;
use GUIDeFATE;

my $window=<<END;
+--------------------------------------+
|T Start other apps                    |
+M-------------------------------------+
|  {Use Win32}    wx    {Use Tk   }    |
|  {Calculator                      }  |
|  {Rock Paper Scissors Lizard Spock}  |
|  {GUI Gnuplotter                  }  |
|  { Text editor                    }  |
+--------------------------------------+

END


my $backend="tk";
my $gui=GUIDeFATE->new($window,$backend);
my $frame=$gui->getFrame;
$gui->MainLoop;



sub btn0 #called using button with label Calculator                       
  {
	  $backend="win32";
	  $frame->setLabel("stattext2","Win32");
  }
  
  sub btn1 #called using button with label Calculator                       
  {
	  $backend="tk";
	  $frame->setLabel("stattext2","Tk");
  }

sub btn3 #called using button with label Calculator                       
  {
  system("(start /b perl -I..\\lib\\ calculator.pl $backend )");
   };
sub btn4 #called using button with label Rock Paper Scissors Lizard Spock 
  {
  system("(start /b perl -I..\\lib\\ rpsls.pl $backend )");
  };

sub btn5 #called using button with label GUI Gnuplotter                   
  {
  system("(start /b perl -I..\\lib\\ GUIgnuplot.pl $backend )");
   };

sub btn6 #called using button with label  Text editor                     
  {
  system("(start /b perl -I..\\lib\\ texteditor.pl $backend )");
   };

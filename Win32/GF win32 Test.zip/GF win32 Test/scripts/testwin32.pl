#!/usr/bin/env perl 
  use Win32::GUI();
 # use Win32::GUI::DIBitmap;
  use Image::Magick;
    $main = Win32::GUI::Window->new(
                -name   => 'Main',
                -width  => 600,
                -height => 400,
        );
    my $image = Image::Magick->new;
	my $x=$image->Read("Lizard.jpg");
	    warn "$x" if "$x"; 
	my $geom="600X400!";
	$x=$image->Scale(geometry => $geom);
	 warn "$x" if "$x";
	my $x=$image->Write("Lizard.bmp");
	 warn "$x" if "$x";
    my $bmp = new Win32::GUI::Bitmap("Lizard.bmp");
   # $hbitmap = newFromFile Win32::GUI::DIBitmap ('Lizard.jpg')->ConvertToBitmap();
    $main->AddLabel(-bitmap => $bmp);
    $main->Show();
    Win32::GUI::Dialog();

    sub Main_Terminate {
        -1;
    }

#!/usr/bin/env perl 

use Win32::GUI;
use Image::Magick;

$main = new Win32::GUI::Window(
        -name        => 'Main',
        -title        => 'temp',
        -width        => '325',
        -height        => '310',
    );

$main->Show();
my $tmp=();

    my $image = Image::Magick->new;
	my $x=$image->Read("Lizard.jpg");
	    warn "$x" if "$x"; 
	my $geom="50X50!";
	$x=$image->Scale(geometry => $geom);
	 warn "$x" if "$x";
	my $x=$image->Write("BMP2:GF.bmp");
	 warn "$x" if "$x";
	 
	 help();
sub help{

$tmp->{"er"}=$main->AddLabel(
            -text => 'pic',
            -style => 14,
            -visible => '1',
            -pos     =>  [50,50],
            -background => [255,255,255],
            -foreground => [0,0,0],
            );
$tmp->{"ty"}=$main->AddLabel(
            -text => 'pic',
            -style => 14,
            -visible => '1',
            -pos     =>  [100,100],
            -size    =>  [50,50],
            -background => [255,255,255],
            -foreground => [0,0,0],
            );

$tmp->{"er"}->SetImage(new Win32::GUI::Bitmap("GF.bmp"));
$tmp->{"ty"}->SetImage(new Win32::GUI::Bitmap("GFtmp.bmp"));
}


Win32::GUI::Dialog();

sub Main_Terminate    { -1; }

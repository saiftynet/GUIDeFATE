package GFwin32;
   use strict;
   use warnings;
   
   our $VERSION = '0.09x';
   
   use Win32::GUI; ##
   #use Win32::GUI::DIBitmap;
   use Image::Magick;

   use Exporter 'import';     ##somefunctions are always passed back to GUIDeFATE.pm
   our @EXPORT  = qw<addWidget addVar setScale MainLoop $frame $winScale $winWidth $winHeight $winTitle>;

   our $frame;                #  The frame which is the parent of all the widgets
                              #  ever widget is referenced by an id and is accessible by $frame -> {id}
   
   our $winX=30;              #  These are the window dimensions and are modified by GUIDeFATE
   our $winY=30;
   our $winWidth;
   our $winHeight;
   our $winTitle;
   our $winScale=6.5;         #  This allows the window to be scaled
 
   # these arrays will contain the widgets each as an arrayref of the parameters
   # It may be logical to group them as one array conatining eveything and this
   # may be the way to go when ready to push out v1.0
   my @widgets=();
   my %iVars=();     #vars for interface operation (e.g. 
   my %oVars=();      #vars for interface creation (e.g. list of options)
   my %styles;   # styles is a future mod that allows widgets to be styled

   my $lastMenuLabel;
   
   sub new
   {
       my $class=shift;
       my $self={};
       bless ($self,$class);
       $self->{Window}= new Win32::GUI::Window(
                 -name  =>  "GF",
                 -title =>  $winTitle,
                 -pos   =>  [ $winX,$winY ],
                 -size  =>  [ $winWidth, $winHeight+50 ],
               );
       $self->{Window}->Show();
       $self->{font} = Win32::GUI::Font->new(
                -name => "Arial", 
                -size => 16,
        );
       &setupContent($self, $self->{Window} );

       
       return $self; 
   };

  sub MainLoop{
    Win32::GUI::Dialog();
    my $ok=42;
  };
  
  sub GF_Terminate { return -1; }
  
# setupContent  sets up the initial content before Mainloop can be run.
   sub setupContent{
	   my ($self, $canvas)=@_;
	   $self ->{"menubar"}=undef;
       my $currentMenu;
	   foreach my $widget (@widgets){
		   my @params=@$widget;
		   my $wtype=shift @params;
		   if ($wtype eq "btn")             {aBt($self, $canvas, @params);}
		   elsif ($wtype eq "textctrl")     {aTC($self, $canvas, @params);}
		   elsif ($wtype eq "stattext")     {aST($self, $canvas, @params);}
		   elsif ($wtype eq "sp")           {aSP($self, $canvas, @params);}
		   elsif ($wtype eq "combo")        {aCB($self, $canvas, @params);}
		   elsif ($wtype eq "sp")           {aSP($self, $canvas, @params);}
		   elsif ($wtype eq "mb")
		                   {
							   if (! $self->{"menubar"}){
							      $self ->{"menubar"} = Win32::GUI::Menu->new();;
		                          $canvas->SetMenu($self ->{"menubar"});
		                          }
	                          $currentMenu=aMB($self,$canvas,$currentMenu,@params)
	       }
	   }
	   
	   # these functions convert the parameters of the widget into actual widgets
	   sub aBt{  # creates buttons
	    my ($self,$frame, $id, $label, $location, $size, $action)=@_;
	    $self->{"btn$id"}=$frame->AddButton(
                -name => "btn$id",
                -text => $label,
                -pos  => $location,
                -size => $size,
                -onClick => $action, 
        );
	    # button id are "btn".$id,  action is generally also a function called "btn".$id
	    # referenced by $frame->{"btn".$id}
        }
       sub aTC{ # single line text entry
		my ($self,$frame, $id, $text, $location, $size, $action)=@_;
		$self->{"textctrl$id"} = $frame->AddTextfield(
		-text   => $text,
        -pos    => $location,
        -size   => $size,
    );
        }
       sub aST{  #static texts
		my ($self,$frame, $id, $text, $location)=@_;
		$self->{"stattext$id"} = $frame->AddLabel(
                -text  => $text,
                -font  => $self->{font},
                -pos   => $location,
                -wrap  => 0,
                -truncate => 0,
                -foreground => [255, 0, 0],
           );
        }
       sub aCB{  
		   my ($self,$canvas, $id, $label, $location, $size, $action)=@_;

	   }
       sub aMB{  #parses the menu items into a menu.   menus may need to be a child of main window
	     my ($self,$canvas,$currentMenu, $id, $label, $type, $action)=@_; 
	     if (($lastMenuLabel) &&($label eq $lastMenuLabel)){return $currentMenu} # bug workaround 
	     else {$lastMenuLabel=$label};	                                         # in menu generator
	    
	     
	       if ($type eq "menuhead"){  #the label of the menu
			   
		   }
		   elsif ($type eq "radio"){   #menu items which are radio buttons in tk there is no function called
			    
		   }
		   elsif ($type eq "check"){  #menu items which are check boxes in tk there is no function called
			    
		   }
		   elsif ($type eq "separator"){ #separators
			    
		   }
		   else{
			   #if($currentMenu!~m/$label/){  #simple menu items }
		   }
		   return $currentMenu;
	   }
	   sub aSP{
			 my ($self,$frame, $id, $panelType, $content, $location, $size)=@_;  ##image Id must endup $id+1
			 if ($panelType eq "I"){  # Image panels start with I
				$content=~s/^\s+|\s+$//g; 
				$self->{"Image$id"} = $frame->AddLabel(
				-text  => "GFPic",
				-style => '14',
				-visible => '1',
				-background => [255,255,255],
				-foreground => [0,0,0],
                -pos   => $location,
                );
                $self->{"Image$id"}->SetImage( new Win32::GUI::Bitmap("GFtmp.bmp") );
				if (-e $content){
			     my $image = Image::Magick->new;
				 my $r =  $image->Read("$content"); warn $r if $r; 
			     my $geom=${$size}[0]."x".${$size}[1]."!";
			     $r = $image->Scale(geometry => $geom); warn $r if $r; 
			     $r = $image->Write("BMP2:GFtmp.bmp"); warn $r if $r; 
			     $self->{"Image$id"}->SetImage( new Win32::GUI::Bitmap("GFtmp.bmp") );
			   }
				
                
		     }
			 
			if ($panelType eq "T"){    # text entry panels start with T
				$content=~s/^\s+|\s+$//g;my $image = Image::Magick->new;
			    $self->{"TextCtrl$id"} = $frame->AddTextfield(
		            -text   => $content,
		            -multiline => 1,
		            -autohscroll => 1,
		            -autovscroll => 1,
                    -pos    => $location,
                    -size   => $size,
                 );
			 }
		 }
	 }


       
#functions for GUIDeFATE to load the widgets into the backend
   sub addWidget{
	   push (@widgets,shift );
   }
   sub addStyle{
	   my ($name,$style)=@_;
	   $styles{$name}=$style;
   }
   sub addVar{
	   my ($varName,$value)=@_;
	   $oVars{$varName}=$value;
   }

# Functions for internal use 
   sub getSize{
	   my ($self,$id)=@_;
	   my $found=getItem($self,$id);
	   return ( $found!=-1) ? $widgets[$found][5]:0;
	   
   }
   sub getLocation{
	   my ($self,$id)=@_;
	   my $found=getItem($self,$id);
	   return ( $found!=-1) ? $widgets[$found][3]:0;
	   
   }   
   sub getItem{
	   my ($self,$id)=@_;
	   $id=~s/[^\d]//g;
	   my $i=0; my $found=-1;
	   while ($i<@widgets){
		   if ($widgets[$i][1]==$id) {
			   $found=$i;
			   }
		   $i++;
	   }
	   return $found;
   }

   sub setScale{
	   $winScale=shift;	   
   };

   sub getFrame{
	 my $self=shift;
	return $self;
   };

#  The functions for GUI Interactions
#  Static Text functions
   sub setLabel{
	   my ($self,$id,$text)=@_;
	   $self->{$id}->Text(""); # label persists...but not contains empty string? how to delete?
	   my $location=getLocation($self,$id,\@widgets);
	   $self->{$id} = $self->{Window}->AddLabel(
                -text  => $text,
                -font  => $self->{font},
                -pos   => $location,
           )
   }

#Image functions
   sub setImage{
	   my ($self,$id,$file)=@_;
	   my $size=getSize($self,$id,\@widgets);
	   my $location=getLocation($self,$id,\@widgets);
       my $image = Image::Magick->new;
	   my $r =  $image->Read("$file"); warn $r if $r; 
	   my $geom=${$size}[0]."x".${$size}[1]."!";
	   $r = $image->Scale(geometry => $geom); warn $r if $r; 
	   $r = $image->Write("BMP2:GFtmp.bmp"); warn $r if $r;
	   print $id . "\n"; 
	   $self->{$id}->SetImage( new Win32::GUI::Bitmap("GFtmp.bmp") );
   };

#Text input functions
  sub getValue{
	   my ($self,$id)=@_;
	   if ($id=~/^combo/){ return $self->{$id}->SelectedItem();}
	   else { return $self->{$id}->Text();}
	   # function to get value of an input box
   }
   sub setValue{
	   my ($self,$id,$text)=@_;
	   $self->{$id}->Text( $text );  
   }   
   sub appendValue{
	   my ($self,$id,$text)=@_;
	   $self->{$id}->Append( $text ); 
   }   

#Message box, Fileselector and Dialog Boxes
   sub showFileSelectorDialog{
	 
     my ($self, $message,$load) = @_;  # Message is the title of the fileselector
                                       # Load is 1 if loading or 0 if saving
     my $filename;
     ##  fileselector routine  
	 return $filename;

   };
      sub showDialog{
	   my ($self, $title, $message,$response,$icon) = @_;
	   my %responses=( YNC=>'YesNoCancel',
	                   YN =>'YesNo',
	                   OK => 'Ok',
	                   OKC=>'OkCancel' );
	                   
	   my %icons= (  "!"=>"warning",
	                 "?"=>"question",
	                 "E"=>"error",
	                 "H"=>"warning",
	                 "I"=>"info" );
	   $response=$response?$responses{$response}:"ok";
	   $icon=$icon?$icons{$icon}:"info";
	   my $answer="";  # messagebox creationn  statement here
       return (($answer eq "Ok")||($answer eq "Yes"))
   };
   
# Quit
   sub quit{
	   my ($self) = @_;
	   $self ->GF_Terminate;
   }
1;

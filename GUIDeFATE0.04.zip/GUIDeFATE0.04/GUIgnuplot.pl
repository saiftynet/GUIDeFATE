#!/usr/bin/env perl 
#A test script that crtaes a minimalist gui gnuplot
#use GUIDeFATE (which in turn depends on Wx)

use strict;
use warnings;
use GUIDeFATE qw<$frame>;
use File::Copy qw(copy);

my $window=<<END;
+------------------------------------------------------------------------------+
|T  Test GnuPlot                                                               |
+M-----------------------------------------------------------------------------+
|+T------------------------------------++I------------------------------------+|
||plot sin(x)                          ||plotter.png                          ||
||                                     ||                                     ||
||                                     ||                                     ||
||                                     ||                                     ||
||                                     ||                                     ||
||                                     ||                                     ||
||                                     ||                                     ||
||                                     ||                                     ||
||                                     ||                                     ||
||                                     ||                                     ||
||                                     ||                                     ||
||                                     ||                                     ||
|+-------------------------------------++-------------------------------------+|
|                                                                              |
+------------------------------------------------------------------------------+

Menu
-File
--New
--Open
--Save
--Quit
-Chart
--Plot
--Save As
END

GUIDeFATE::convert($window);
my $gui=GUIDeFATE->new();
menu12();
$gui->MainLoop;

sub menu6{
	if($frame->showDialog("Sure?","This will wipe existing text...proceed?","OKC","!")){
	   $frame->{TextCtrl1}->SetValue("");
   }
}
sub menu7{
	if($frame->showDialog("Sure?","This will wipe existing text...proceed?","OKC","!")){
	  $frame->{TextCtrl1}->SetValue("");
	  my $file= $frame->showFileSelectorDialog("Open file",1);
	    if (open(my $fh, '<:encoding(UTF-8)', $file)) {
          while (my $row = <$fh>) {
             $frame->{TextCtrl1}->AppendText($row)
          }
       close $fh;
      }
  }
}
sub menu8{
	my $file= $frame->showFileSelectorDialog("Save file",0);
	if (open(my $fh, '>', $file)) {
       print $fh  $frame->{TextCtrl1}->GetValue();
       close $fh
       }
    }
    
sub menu9{
	$frame->quit();
}
sub menu12{
	open(GP, "| gnuplot") or die "Error while piping to Gnuplot: $! \n";
	print GP <<END;
set terminal pngcairo size 600,500
set lmargin at screen 80.0/600
set rmargin at screen 579.0/600
set border back
set output 'plotter.png'
END
	print GP $frame->{TextCtrl1}->GetValue();
    
    close(GP);
    $frame->setImage("plotter.png",2)
}
sub menu13{
	my $file= $frame->showFileSelectorDialog("Save plot image file",0);
	copy("plotter.png", $file)

}
sub menu14{
	
}


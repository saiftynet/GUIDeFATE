#!/usr/bin/env perl 
#A test script that calls the test files in scripts folder
#use GUIDeFATE (which in turn depends on Wx)

use lib '../lib/';
use strict;
use warnings;
use GUIDeFATE;

my $window=<<END;
+--------------------------------------+
|T Start other apps                    |
+M-------------------------------------+
|  {Calculator                      }  |
|  {Rock Paper Scissors Lizard Spock}  |
|  {GUI Gnuplotter                  }  |
|  { Text editor                    }  |
+--------------------------------------+

END

my $gui=GUIDeFATE->new($window,"tk");
$gui->MainLoop;

sub btn0 #called using button with label Calculator                       
  {
  system("(perl -I../lib/ calculator.pl &)");
   };

sub btn1 #called using button with label Rock Paper Scissors Lizard Spock 
  {
  system("(perl -I../lib/ rpsls.pl &)");
  };

sub btn2 #called using button with label GUI Gnuplotter                   
  {
  system("(perl -I../lib/ GUIgnuplot.pl &)");
   };

sub btn3 #called using button with label  Text editor                     
  {
  system("(perl -I../lib/ texteditor.pl &)");
   };
